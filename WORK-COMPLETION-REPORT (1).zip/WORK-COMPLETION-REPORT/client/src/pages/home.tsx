import React from 'react';
import Header from '@/components/header';
import Footer from '@/components/footer';
import ReportForm from '@/components/report-form';
import SavedReports from '@/components/saved-reports';

const Home: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-900 text-slate-100">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          <ReportForm />
          <SavedReports />
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Home;
