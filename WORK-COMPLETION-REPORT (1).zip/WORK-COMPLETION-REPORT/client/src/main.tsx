import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Apply dark mode based on preferred color scheme (always dark for this app per design)
document.documentElement.classList.add('dark');

createRoot(document.getElementById("root")!).render(<App />);
