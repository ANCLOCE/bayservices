import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { List, Download, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { type Report } from '@shared/schema';
import { generateReportPDF } from '@/lib/report-pdf';

const SavedReports: React.FC = () => {
  // Fetch saved reports
  const { data: savedReports = [], isLoading, isError } = useQuery({
    queryKey: ['/api/reports'],
  });

  const handleExportPDF = async (report: Report) => {
    try {
      await generateReportPDF(report);
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="bg-slate-800 shadow-2xl rounded-xl p-6 sm:p-8">
        <h2 className="text-2xl font-semibold mb-6 text-primary flex items-center">
          <List size={28} className="mr-3" /> Loading Reports...
        </h2>
        <div className="animate-pulse flex flex-col space-y-4">
          <div className="h-24 bg-slate-700 rounded-lg"></div>
          <div className="h-24 bg-slate-700 rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="bg-slate-800 shadow-2xl rounded-xl p-6 sm:p-8">
        <h2 className="text-2xl font-semibold mb-6 text-red-500 flex items-center">
          <List size={28} className="mr-3" /> Error Loading Reports
        </h2>
        <p className="text-slate-300">There was an error loading your saved reports. Please try again later.</p>
      </div>
    );
  }

  if (savedReports.length === 0) {
    return (
      <div className="text-center py-10 bg-slate-800 shadow-xl rounded-xl">
        <List size={48} className="mx-auto text-slate-500 mb-4" />
        <p className="text-xl text-slate-400">No reports saved yet.</p>
        <p className="text-sm text-slate-500">Fill out the form above to add your first report.</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-800 shadow-2xl rounded-xl p-6 sm:p-8">
      <h2 className="text-2xl font-semibold mb-6 text-primary flex items-center">
        <List size={28} className="mr-3" /> Previously Saved Reports
      </h2>
      
      <div className="space-y-4">
        {savedReports.map((report: Report) => (
          <div key={report.id} className="bg-slate-700/70 p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-3">
              <h3 className="text-xl font-semibold text-cyan-400">{report.propertyName}</h3>
              <div className="flex mt-2 sm:mt-0">
                <Button 
                  onClick={() => handleExportPDF(report)} 
                  className="inline-flex items-center px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-md mr-2 transition-colors"
                  size="sm"
                >
                  <Download className="h-4 w-4 mr-1" />
                  PDF
                </Button>
                <Button 
                  className="inline-flex items-center px-3 py-1.5 bg-slate-600 hover:bg-slate-500 text-white text-sm font-medium rounded-md transition-colors"
                  size="sm"
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Edit
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <p className="text-sm text-slate-300"><span className="font-medium">Date:</span> {report.reportDate}</p>
                <p className="text-sm text-slate-300"><span className="font-medium">Technician:</span> {report.technician}</p>
                <div className="mt-2">
                  <p className="text-slate-200 whitespace-pre-wrap text-sm">{report.workDescription}</p>
                </div>
              </div>
              {report.photos && report.photos.length > 0 && (
                <div>
                  <p className="text-xs font-medium text-slate-400 mb-2">Photos ({report.photos.length}):</p>
                  <div className="flex flex-wrap gap-2">
                    {report.photos.map((photo) => (
                      <div key={photo.id} className="relative group">
                        <img 
                          src={photo.fileData} 
                          alt={photo.caption || photo.fileName} 
                          className="h-14 w-20 object-cover rounded"
                        />
                        {photo.caption && (
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-70 flex items-center justify-center transition-all duration-200 opacity-0 group-hover:opacity-100">
                            <span className="text-xs text-white text-center px-1">{photo.caption}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SavedReports;
