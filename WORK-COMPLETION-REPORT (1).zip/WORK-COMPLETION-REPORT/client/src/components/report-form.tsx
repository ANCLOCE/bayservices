import React, { useState, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { Photo, insertReportSchema } from '@shared/schema';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { RotateCcw, Send, Camera } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from '@/components/ui/select';

// Extend the insert schema with more validation
const formSchema = insertReportSchema
  .extend({
    propertyId: z.coerce.number().optional(),
    propertyName: z.string(),
    reportDate: z.string(),
    technician: z.string(),
    workDescription: z.string(),
  });

type FormValues = z.infer<typeof formSchema>;

const ReportForm: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  
  // Fetch properties from API
  const { data: properties = [], isLoading: isLoadingProperties } = useQuery({
    queryKey: ['/api/properties'],
  });

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      propertyId: 1, // Default ID
      propertyName: '',
      reportDate: new Date().toISOString().split('T')[0],
      technician: '',
      workDescription: '',
      photos: [],
    },
  });

  // Handle photo upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          const newPhoto: Photo = {
            id: uuidv4(),
            fileName: file.name,
            fileData: event.target.result as string,
            caption: '',
          };
          
          setPhotos(prev => [...prev, newPhoto]);
        }
      };
      reader.readAsDataURL(file);
    });
    
    // Clear the input value so the same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Handle photo caption update
  const updatePhotoCaption = (id: string, caption: string) => {
    setPhotos(prev => 
      prev.map(photo => 
        photo.id === id ? { ...photo, caption } : photo
      )
    );
  };

  // Handle photo removal
  const removePhoto = (id: string) => {
    setPhotos(prev => prev.filter(photo => photo.id !== id));
  };

  // Form submission
  const mutation = useMutation({
    mutationFn: async (data: FormValues) => {
      return apiRequest('POST', '/api/reports', {
        ...data,
        photos,
      });
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Report has been saved successfully.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/reports'] });
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save report: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormValues) => {
    mutation.mutate(data);
  };

  const resetForm = () => {
    form.reset();
    setPhotos([]);
    toast({
      title: "Form Reset",
      description: "The form has been cleared.",
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="bg-slate-800 shadow-2xl rounded-xl p-6 sm:p-8">
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-2 text-primary flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Create Dryer Vent Cleaning Report
          </h2>
          <p className="text-slate-400">Fill out the form below to create a new cleaning report</p>
        </div>

        <div className="space-y-6">
          {/* Property Information */}
          <FormField
            control={form.control}
            name="propertyName"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-slate-300">Property Information</FormLabel>
                <FormControl>
                  <Input
                    className="bg-slate-700 border-slate-600 text-slate-100 focus:ring-primary"
                    placeholder="Enter property details (name, address, etc.)"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Date and Technician */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="reportDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Service Date</FormLabel>
                  <FormControl>
                    <Input
                      type="date"
                      className="bg-slate-700 border-slate-600 text-slate-100 focus:ring-primary"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="technician"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Technician Name</FormLabel>
                  <FormControl>
                    <Input
                      className="bg-slate-700 border-slate-600 text-slate-100 focus:ring-primary"
                      placeholder="Enter name"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Work Description */}
          <FormField
            control={form.control}
            name="workDescription"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-slate-300">Work Description</FormLabel>
                <FormControl>
                  <Textarea
                    rows={4}
                    className="bg-slate-700 border-slate-600 text-slate-100 focus:ring-primary"
                    placeholder="Describe the work performed..."
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Photo Upload */}
          <div>
            <FormLabel className="text-slate-300 block mb-2">Photos</FormLabel>
            <div className="mb-4 flex flex-wrap items-center">
              <div className="relative mr-4 mb-4">
                <input
                  ref={fileInputRef}
                  type="file"
                  id="photo-upload"
                  name="photos"
                  multiple
                  accept="image/*"
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  onChange={handlePhotoUpload}
                />
                <div className="flex items-center justify-center border-2 border-dashed border-slate-500 bg-slate-700 hover:bg-slate-600 transition-colors h-20 w-28 rounded-md px-2">
                  <div className="text-center">
                    <Camera className="h-6 w-6 mx-auto text-slate-400" />
                    <span className="text-xs text-slate-400">Add Photos</span>
                  </div>
                </div>
              </div>

              {photos.map(photo => (
                <div key={photo.id} className="relative mr-4 mb-4 group">
                  <img
                    src={photo.fileData}
                    alt={photo.fileName}
                    className="h-20 w-28 object-cover rounded-md"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-70 p-1">
                    <input
                      type="text"
                      value={photo.caption || ''}
                      onChange={(e) => updatePhotoCaption(photo.id, e.target.value)}
                      className="w-full text-xs bg-transparent text-white focus:outline-none"
                      placeholder="Add caption..."
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => removePhoto(photo.id)}
                    className="absolute -top-2 -right-2 bg-red-500 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-white"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t border-slate-700">
            <Button
              type="submit"
              disabled={mutation.isPending || !form.formState.isDirty}
              className="flex-1 inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {mutation.isPending ? <RotateCcw className="animate-spin h-5 w-5 mr-2" /> : <Send size={20} className="mr-2"/>}
              {mutation.isPending ? 'Saving...' : 'Save Report'}
            </Button>
            <Button
              type="button"
              onClick={resetForm}
              className="flex-1 inline-flex items-center justify-center px-6 py-3 border border-slate-600 text-base font-medium rounded-md shadow-sm text-slate-300 bg-slate-700 hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-slate-500 transition-colors"
            >
              <RotateCcw size={20} className="mr-2" />
              Clear All & Reset
            </Button>
          </div>
        </div>
      </form>
    </Form>
  );
};

export default ReportForm;
