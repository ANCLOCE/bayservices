import React from 'react';
import { Link } from 'wouter';
import { User } from 'lucide-react';

interface HeaderProps {
  username?: string;
}

const Header: React.FC<HeaderProps> = ({ username = "John Technician" }) => {
  return (
    <header className="bg-slate-800 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-10 w-10 rounded-full bg-white p-1 text-slate-700"
              >
                <path d="M4 22V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v18l-8-4-8 4z" />
                <path d="M12 11.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z" />
                <path d="M16 22v-4a4 4 0 0 0-8 0v4" />
              </svg>
              <h1 className="ml-3 text-xl font-bold text-white">Dryer Vent Pro Reports</h1>
            </div>
          </Link>
        </div>
        <div>
          <button
            type="button"
            className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-slate-700 hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-blue-500 transition-colors"
          >
            <User className="h-5 w-5 mr-2" />
            {username}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
