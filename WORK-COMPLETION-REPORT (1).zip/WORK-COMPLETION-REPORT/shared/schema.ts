import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (already defined, keeping for reference)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Properties table
export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
});

export const insertPropertySchema = createInsertSchema(properties).pick({
  name: true,
  address: true,
});

export type InsertProperty = z.infer<typeof insertPropertySchema>;
export type Property = typeof properties.$inferSelect;

// Photo model for dryer vent reports
export const photoSchema = z.object({
  id: z.string(), 
  fileName: z.string(),
  fileData: z.string(), // Base64 encoded image data
  caption: z.string().optional(),
});

export type Photo = z.infer<typeof photoSchema>;

// Reports table
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  propertyId: integer("property_id").notNull(),
  propertyName: text("property_name").notNull(),
  reportDate: text("report_date").notNull(), // Using text for date in YYYY-MM-DD format
  technician: text("technician").notNull(),
  workDescription: text("work_description").notNull(),
  photos: jsonb("photos").default([]).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertReportSchema = createInsertSchema(reports).pick({
  propertyId: true,
  propertyName: true,
  reportDate: true,
  technician: true,
  workDescription: true,
  photos: true,
});

export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;
