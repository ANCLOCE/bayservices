import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { insertReportSchema, photoSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  app.get("/api/properties", async (req, res) => {
    try {
      const properties = await storage.getProperties();
      res.json(properties);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch properties",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.get("/api/properties/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid property ID" });
      }

      const property = await storage.getProperty(id);
      if (!property) {
        return res.status(404).json({ message: "Property not found" });
      }

      res.json(property);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch property",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.get("/api/reports", async (req, res) => {
    try {
      const propertyId = req.query.propertyId;
      
      if (propertyId) {
        const id = parseInt(propertyId as string);
        if (isNaN(id)) {
          return res.status(400).json({ message: "Invalid property ID" });
        }
        const reports = await storage.getReportsByPropertyId(id);
        return res.json(reports);
      }
      
      const reports = await storage.getReports();
      res.json(reports);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch reports",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.post("/api/reports", async (req, res) => {
    try {
      // Validate the report data
      const validatedReport = insertReportSchema.parse(req.body);
      
      // Skip property validation since we're allowing manual entry
      // If propertyId is provided but not found, we'll still create the report

      // Validate photos if present
      if (validatedReport.photos && validatedReport.photos.length > 0) {
        // Validate each photo
        const photosArray = z.array(photoSchema).parse(validatedReport.photos);
        validatedReport.photos = photosArray;
      } else {
        // Ensure photos is always an array
        validatedReport.photos = [];
      }
      
      const report = await storage.createReport(validatedReport);
      res.status(201).json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid report data", 
          errors: fromZodError(error).message
        });
      }
      
      res.status(500).json({ 
        message: "Failed to create report",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.get("/api/reports/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid report ID" });
      }

      const report = await storage.getReport(id);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }

      res.json(report);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch report",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.put("/api/reports/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid report ID" });
      }

      // Make sure report exists
      const existingReport = await storage.getReport(id);
      if (!existingReport) {
        return res.status(404).json({ message: "Report not found" });
      }

      // Partial validation for update
      const updateSchema = insertReportSchema.partial();
      const validatedUpdate = updateSchema.parse(req.body);
      
      // If propertyId is included, make sure the property exists
      if (validatedUpdate.propertyId) {
        const property = await storage.getProperty(validatedUpdate.propertyId);
        if (!property) {
          return res.status(404).json({ message: "Property not found" });
        }
      }

      const updatedReport = await storage.updateReport(id, validatedUpdate);
      res.json(updatedReport);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid report data", 
          errors: fromZodError(error).message
        });
      }
      
      res.status(500).json({ 
        message: "Failed to update report",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.delete("/api/reports/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid report ID" });
      }

      // Make sure report exists
      const existingReport = await storage.getReport(id);
      if (!existingReport) {
        return res.status(404).json({ message: "Report not found" });
      }

      await storage.deleteReport(id);
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to delete report",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
