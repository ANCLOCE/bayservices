import { 
  users, type User, type InsertUser, 
  properties, type Property, type InsertProperty,
  reports, type Report, type InsertReport, 
  type Photo
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Property operations
  getProperties(): Promise<Property[]>;
  getProperty(id: number): Promise<Property | undefined>;
  createProperty(property: InsertProperty): Promise<Property>;

  // Report operations
  getReports(): Promise<Report[]>;
  getReport(id: number): Promise<Report | undefined>;
  getReportsByPropertyId(propertyId: number): Promise<Report[]>;
  createReport(report: InsertReport): Promise<Report>;
  updateReport(id: number, report: Partial<InsertReport>): Promise<Report | undefined>;
  deleteReport(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private properties: Map<number, Property>;
  private reports: Map<number, Report>;
  
  private userCounter: number;
  private propertyCounter: number;
  private reportCounter: number;

  constructor() {
    this.users = new Map();
    this.properties = new Map();
    this.reports = new Map();
    
    this.userCounter = 1;
    this.propertyCounter = 1;
    this.reportCounter = 1;

    // Seed some default properties
    this.seedDefaultProperties();
  }

  private seedDefaultProperties() {
    const defaultProperties = [
      { name: "123 Main St", address: "Apartment Complex" },
      { name: "456 Oak Avenue", address: "Highland Condos" },
      { name: "789 Pine Boulevard", address: "Westview Homes" },
      { name: "321 Cedar Lane", address: "Bayside Residences" },
    ];

    defaultProperties.forEach(prop => {
      this.createProperty(prop);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Property operations
  async getProperties(): Promise<Property[]> {
    return Array.from(this.properties.values());
  }

  async getProperty(id: number): Promise<Property | undefined> {
    return this.properties.get(id);
  }

  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const id = this.propertyCounter++;
    const property: Property = { ...insertProperty, id };
    this.properties.set(id, property);
    return property;
  }

  // Report operations
  async getReports(): Promise<Report[]> {
    return Array.from(this.reports.values());
  }

  async getReport(id: number): Promise<Report | undefined> {
    return this.reports.get(id);
  }

  async getReportsByPropertyId(propertyId: number): Promise<Report[]> {
    return Array.from(this.reports.values()).filter(
      (report) => report.propertyId === propertyId
    );
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    const id = this.reportCounter++;
    const now = new Date();
    // Ensure photos is always an array
    const photos = Array.isArray(insertReport.photos) ? insertReport.photos : [];
    
    const report: Report = { 
      ...insertReport, 
      photos,
      id, 
      createdAt: now
    };
    this.reports.set(id, report);
    return report;
  }

  async updateReport(id: number, updateData: Partial<InsertReport>): Promise<Report | undefined> {
    const report = this.reports.get(id);
    if (!report) return undefined;

    // Handle photos properly
    const photos = updateData.photos 
      ? (Array.isArray(updateData.photos) ? updateData.photos : []) 
      : report.photos;

    const updatedReport: Report = { 
      ...report, 
      ...updateData,
      photos,
    };
    
    this.reports.set(id, updatedReport);
    return updatedReport;
  }

  async deleteReport(id: number): Promise<boolean> {
    return this.reports.delete(id);
  }
}

// Import the database storage implementation
import { DatabaseStorage } from "./storage-db";

// Create an instance of the database storage
const dbStorage = new DatabaseStorage();

// Seed default properties
dbStorage.seedDefaultProperties().catch(err => {
  console.error("Error seeding default properties:", err);
});

// Export the database storage as the main storage
export const storage = dbStorage;
