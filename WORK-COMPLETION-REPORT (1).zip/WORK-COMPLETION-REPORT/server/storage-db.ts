import { 
  users, type User, type InsertUser,
  properties, type Property, type InsertProperty,
  reports, type Report, type InsertReport,
  type Photo
} from "@shared/schema";
import { db } from "./db";
import { eq, asc } from "drizzle-orm";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Property operations
  async getProperties(): Promise<Property[]> {
    return db.select().from(properties).orderBy(asc(properties.name));
  }

  async getProperty(id: number): Promise<Property | undefined> {
    const [property] = await db.select().from(properties).where(eq(properties.id, id));
    return property || undefined;
  }

  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const [property] = await db
      .insert(properties)
      .values(insertProperty)
      .returning();
    return property;
  }

  // Report operations
  async getReports(): Promise<Report[]> {
    return db.select().from(reports).orderBy(asc(reports.id));
  }

  async getReport(id: number): Promise<Report | undefined> {
    const [report] = await db.select().from(reports).where(eq(reports.id, id));
    return report || undefined;
  }

  async getReportsByPropertyId(propertyId: number): Promise<Report[]> {
    return db.select()
      .from(reports)
      .where(eq(reports.propertyId, propertyId))
      .orderBy(asc(reports.id));
  }

  async createReport(insertReport: InsertReport): Promise<Report> {
    // Ensure photos is an array
    const photos = Array.isArray(insertReport.photos) ? insertReport.photos : [];
    
    const [report] = await db
      .insert(reports)
      .values({
        propertyId: insertReport.propertyId,
        propertyName: insertReport.propertyName,
        reportDate: insertReport.reportDate,
        technician: insertReport.technician,
        workDescription: insertReport.workDescription,
        photos: photos
      })
      .returning();
    return report;
  }

  async updateReport(id: number, updateData: Partial<InsertReport>): Promise<Report | undefined> {
    const existingReport = await this.getReport(id);
    if (!existingReport) return undefined;

    // Handle photos properly
    const photos = updateData.photos !== undefined
      ? (Array.isArray(updateData.photos) ? updateData.photos : [])
      : existingReport.photos;

    const updateValues: any = {};
    
    // Only add fields that are present in the update data
    if (updateData.propertyId !== undefined) updateValues.propertyId = updateData.propertyId;
    if (updateData.propertyName !== undefined) updateValues.propertyName = updateData.propertyName;
    if (updateData.reportDate !== undefined) updateValues.reportDate = updateData.reportDate;
    if (updateData.technician !== undefined) updateValues.technician = updateData.technician;
    if (updateData.workDescription !== undefined) updateValues.workDescription = updateData.workDescription;
    updateValues.photos = photos;

    const [updatedReport] = await db
      .update(reports)
      .set(updateValues)
      .where(eq(reports.id, id))
      .returning();
    
    return updatedReport;
  }

  async deleteReport(id: number): Promise<boolean> {
    const result = await db.delete(reports).where(eq(reports.id, id));
    // Check if any rows were affected by the delete operation
    return result !== undefined;
  }

  // Method to seed default properties if none exist
  async seedDefaultProperties(): Promise<void> {
    const existingProperties = await this.getProperties();
    
    if (existingProperties.length === 0) {
      const defaultProperties = [
        { name: "123 Main St", address: "Apartment Complex" },
        { name: "456 Oak Avenue", address: "Highland Condos" },
        { name: "789 Pine Boulevard", address: "Westview Homes" },
        { name: "321 Cedar Lane", address: "Bayside Residences" },
      ];

      for (const prop of defaultProperties) {
        await this.createProperty(prop);
      }
    }
  }
}